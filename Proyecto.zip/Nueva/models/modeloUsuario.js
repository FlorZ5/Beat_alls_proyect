const sequielize = require ('sequelize')
const db = require('../config/basededatos')

const usuarioModel = db.define("usuarios", {
    id: {
        type:sequelize.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    nombre :{
        type: sequelize.STRING,
        allowNull: false
    },
    apellido :{
        type: sequelize.STRING,
        allowNull: false
    },
  
    usuario:{
        type: sequelize.STRING,
        unique: true,
        allowNull: true
    },
    contrasena:{
        type: sequelize.STRING,
        allowNull: false
    },
    email:{
        type: sequelize.STRING,
        allowNull: true
    },

}); //aqui va nombre de la tabla

module.exports = usuarioModel;