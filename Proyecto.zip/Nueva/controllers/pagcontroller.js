
const usuariosModel = require('../models/modeloUsuario');

const index =   (req,res)=>{
    res.render('index')
}

const login = (req,res)=>{
    res.render('login')
}

const productos =  (req,res)=>{
    res.render('productos')
}

const registro = (req,res)=>{
    res.render('registro')
}

const usuariosReg = async (req,res)=>{

    const usuarios = await usuariosModel.findAll()
    console.log (usuarios);

    res.render('usuariosReg', {titulo: "Usuarios Registrados"})
}



module.exports ={
    index,
    login,
    productos,
    registro,
    usuariosReg
}