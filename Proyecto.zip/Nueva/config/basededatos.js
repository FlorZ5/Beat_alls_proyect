const sequelize = require('sequelize');

const basededatos = new sequelize ('pwp', 'root', '',{
    host: 'localhost' || "127.0.0.1",
    port: "3307",
    dialect:"mysql",
    define:{
        timestamps:false
    },
    pool:{
        max:5,
        min:0,
        arquire:3000,
        idle:10000
    },
    operatorAliases:false
})

module.exports= basededatos;