const express = require('express')
const router = express.Router();



router.get("/login", (req,res)=>{
    res.render('login')
})

router.get("/productos", (req,res)=>{
    res.render('productos')
})

router.get("/carrito", (req,res)=>{
    res.render('carrito')
})

router.get("/menu", (req,res)=>{
    res.render('menu')
})



router.get("/detallecadena", (req,res)=>{
    res.render('detallecadena')
})

router.get("/contactanos", (req,res)=>{
    res.render('contactanos')
})

router.get("/proovedores", (req,res)=>{
    res.render('proovedores')
})

router.get("/usuarios", (req,res)=>{
    res.render('usuarios')
})

router.get("/clienteReg", (req,res)=>{
    res.render('clienteReg')
})

router.get("/tablaProd", (req,res)=>{
    res.render('tablaProd')
})

router.get("/pedidosReal", (req,res)=>{
    res.render('pedidosReal')
})

router.get("/logCliente", (req,res)=>{
    res.render('logCliente')
})

router.get("/logUsuario", (req,res)=>{
    res.render('logUsuario')
})


router.get("/actualizarCliente", (req,res)=>{
    res.render('actualizarCliente')
})

router.get("/actualizarProducto", (req,res)=>{
    res.render('actualizarProducto')
})

router.get("/usuarioRegistrado", (req,res)=>{
    res.render('usuarioRegistrado')
})

router.get("/registrodeUsuario", (req,res)=>{
    res.render('registrodeUsuario')
})












module.exports=router